package org.arkham.cs.gui;

public enum Category {
	
	HATS,
	EFFECTS,
	KITS,
	CURSE_BLOCKS;

}
